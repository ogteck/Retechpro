import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Form extends JFrame{
	String []Device ;
	JLabel label2 = new JLabel("Bungalow Name:  ");
	JLabel label22 = new JLabel();
	JLabel surname = new JLabel("Surname");
	JLabel name = new JLabel("First Name");
	JLabel address = new JLabel("Address");
	JLabel phone = new JLabel("Phone Number");
	JLabel email = new JLabel("Email");
	JTextField fsurname = new JTextField(20);
	JTextField fname = new JTextField(20);
	JTextField faddress = new JTextField(20);
	JTextField fphone = new JTextField(20);
	JTextField femail = new JTextField(20);
	JButton reserve = new JButton("Make Reservation");
	JButton back = new JButton("Go Back");
	JLabel alone = new JLabel("Living alone ? ");
	JCheckBox yesyes = new JCheckBox("Yes");
	JCheckBox nono = new JCheckBox("No");
	ButtonGroup yesno = new ButtonGroup();
	
	JLabel familymembers = new JLabel("<html>Family Members<br> Names:</html>");
	JTextArea ffamilymembers = new JTextArea(2,2);
	JScrollPane sfamilymembers = new JScrollPane(ffamilymembers);
	
	public static void main(String[] args) {
		String[] s = new String[]{"null"};

		Form Form66 = new Form(s);

	}

	public Form(String [] args) {
		this.Device = args;
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);


		add(label2);
		label2.setBounds(200, 40, 200, 30);
		label2.setForeground(Color.white);
		label2.setFont(new Font("",Font.BOLD,20));

		label22.setText(args[0]);
		add(label22);
		label22.setBounds(380, 30, 400, 50);
		label22.setForeground(Color.green);
		label22.setFont(new Font("",Font.BOLD,40));
		
		
		String value22 = label22.getText();
		JTextField forLabel22 = new JTextField();
		forLabel22.setText(value22);
		
		
		add(surname);
		add(name);
		add(address);
		add(phone);
		add(email);
		add(fsurname);
		add(fname);
		add(faddress);
		add(fphone);
		add(femail);
		add(reserve);
		add(back);
		add(alone);
		add(yesyes);
		add(nono);
		yesno.add(yesyes);
		yesno.add(nono);
		add(familymembers);
		add(sfamilymembers);
		
		surname.setBounds(200,90,100,30);
		name.setBounds(200,140,200,30);
		address.setBounds(200,380,200,30);
		phone.setBounds(200,430,200,30);
		email.setBounds(200,480,100,30);
		alone.setBounds(200,190,200,30);
		familymembers.setBounds(200,240,200,50);
		sfamilymembers.setBounds(380,240,200,100);
		
		fsurname.setBounds(330,90,200,30);
		fname.setBounds(330,140,200,30);
		yesyes.setBounds(350,190,70,30);
		nono.setBounds(430,190,50,30);
		
		yesyes.setBackground(Color.gray);
		nono.setBackground(Color.gray);
		if(yesyes.isSelected()) {
			ffamilymembers.disable();
		}
		else
			ffamilymembers.disable();
		
		
		if(nono.isSelected()) {
			ffamilymembers.enable();
		}
		else
			ffamilymembers.disable();
		
		
		
		faddress.setBounds(330,380,200,30);
		fphone.setBounds(360,430,200,30);
		femail.setBounds(280,480,200,30);
		reserve.setBounds(380,530,250,50);
		back.setBounds(200,540,100,30);
		
		surname.setForeground(Color.white);
		name.setForeground(Color.white);
		address.setForeground(Color.white);
		phone.setForeground(Color.white);
		email.setForeground(Color.white);
		alone.setForeground(Color.white);
		yesyes.setForeground(Color.white);
		nono.setForeground(Color.white);
		familymembers.setForeground(Color.white);
		
		surname.setFont(new Font("",Font.BOLD,20));
		name.setFont(new Font("",Font.BOLD,20));
		yesyes.setFont(new Font("",Font.BOLD,15));
		nono.setFont(new Font("",Font.BOLD,15));
		familymembers.setFont(new Font("",Font.BOLD,20));
		address.setFont(new Font("",Font.BOLD,20));
		phone.setFont(new Font("",Font.BOLD,20));
		email.setFont(new Font("",Font.BOLD,20));
		alone.setFont(new Font("",Font.BOLD,20));
		reserve.setFont(new Font("",Font.BOLD,25));
		
		/*
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateTime = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		JLabel labelDateTime = new JLabel();
		labelDateTime.setText(dateTime.format(cal.getTime()));
		add(labelDateTime);*/
		Calendar cal = Calendar.getInstance();
        java.util.Date utilDate = new java.util.Date();
        java.sql.Timestamp sqlTS = new java.sql.Timestamp(utilDate.getTime());
        
        
        yesyes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(yesyes.isSelected()) {
					ffamilymembers.disable();
				}
				else
					ffamilymembers.disable();
			}
		});
        
        nono.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(nono.isSelected()) {
					ffamilymembers.enable();
				}
				else
					ffamilymembers.disable();
			}
		});
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Rent();
				dispose();
				
			}
		});
		
		reserve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
	            
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro", "root", "");
					PreparedStatement std = conn.prepareStatement("insert into reservation(bungalowName,surname,firstName,familyMembers,address,phone,email,dateTime) values(?,?,?,?,?,?,?,?)");
					std.setString(1, forLabel22.getText());
					std.setString(2, fsurname.getText());
					std.setString(3, fname.getText());
					std.setString(4, ffamilymembers.getText());
					std.setString(5, faddress.getText());
					std.setString(6, fphone.getText());
					std.setString(7, femail.getText());
					std.setTimestamp(8, sqlTS);
					
					


		
					String surname1 = surname.getText();
					String firstname = name.getText();
					String address1 = address.getText();
					String phone1 = phone.getText();
					String email1 = email.getText();
					
					if(surname1.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Surname Required");
					}
					else {
						if(firstname.isEmpty()) {
							JOptionPane.showMessageDialog(null, "First Nname Required");
						}
						else {
							if(address1.isEmpty()) {
								JOptionPane.showMessageDialog(null, "Address Required");
							}
							else {
								if(phone1.isEmpty()) {
									JOptionPane.showMessageDialog(null, "Phone Number Required");
								}
								else {
									if(surname1.isEmpty()) {
										JOptionPane.showMessageDialog(null, "Email Required");
									}
									else {
										int x = std.executeUpdate();
										if(x>0) {
											JOptionPane.showMessageDialog(null, "Reservation Successful");
											new Home();
											dispose();
										}
										else {
											JOptionPane.showMessageDialog(null, "Reservation FAILED");
									}
								}
							}
						}
					}
					






					}
				}
				catch(Exception ea) {
					System.out.println(ea);
				}
				
			}
		});
		



	}

}
