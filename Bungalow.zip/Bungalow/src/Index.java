import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;



class MarqueeLabel extends JLabel {  
	public static int LEFT_TO_RIGHT = 1;  
	public static int RIGHT_TO_LEFT = 2;  
	String text;  
	int Option;  
	int Speed;  
	public MarqueeLabel(String text, int Option, int Speed) {  
		this.Option = Option;  
		this.Speed = Speed;  
		this.setText(text);  
	}  
	@Override  
	protected void paintComponent(Graphics g) {  
		if (Option == LEFT_TO_RIGHT) {  
			g.translate((int) ((System.currentTimeMillis() / Speed) % (getWidth() * 2) - getWidth()), 0);  
		} else if (Option == RIGHT_TO_LEFT) {  
			g.translate((int) (getWidth() - (System.currentTimeMillis() / Speed) % (getWidth() * 2)), 0);  
		}  
		super.paintComponent(g);  
		repaint(5);  
	}  
}


public class Index extends JFrame implements ActionListener, MouseListener {
	JMenuBar mainMenu = new JMenuBar();
	JMenu home = new JMenu("HOME");
	JMenu service = new JMenu("SERVICE");
	JMenu about = new JMenu("ABOUT US");
	Font fontsize = new Font("",Font.BOLD,20);
	ImageIcon logo = new ImageIcon("ogteck_logo.png");
	
	MarqueeLabel marquee = new MarqueeLabel("Welcome to Retechpro Support and Services Ltd. We render all form of services in the field of technology. We are located at Famagusta, North Cyprus.", MarqueeLabel.RIGHT_TO_LEFT,20);
	
	ImageIcon icon0 = new ImageIcon("b0.jpg");
	ImageIcon icon1 = new ImageIcon("b1.jpg");
	

	public static void main(String[] args) {
		Index Index66 = new Index();

	}

	public Index() {
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);

		JPanel menuPanel = new JPanel();
		setJMenuBar(mainMenu);
		add(menuPanel);
		menuPanel.add(mainMenu);
		mainMenu.add(home);
		mainMenu.add(service);
		mainMenu.add(about);
		
		menuPanel.setBounds(80,0,820,40);
		home.setFont(fontsize);
		service.setFont(fontsize);
		about.setFont(fontsize);
		
		add(marquee);
		marquee.setBounds(0, 40, 1450, 30);
		marquee.setForeground(Color.white);
		marquee.setFont(fontsize);
		
		
		
		Image logoImg = logo.getImage().getScaledInstance(80, 40, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel logoLabel = new JLabel(logoIcon);
		add(logoLabel);
		logoLabel.setBounds(0, 0, 80, 40);
		
		Image icon00 = icon0.getImage().getScaledInstance(400, 300, Image.SCALE_DEFAULT);
		ImageIcon iconLabel0 = new ImageIcon(icon00);
		JLabel labelIcon0 = new JLabel(iconLabel0);
		add(labelIcon0);
		labelIcon0.setBounds(10, 90, 400, 300);
		labelIcon0.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");
		
		
		Image icon11 = icon1.getImage().getScaledInstance(400, 300, Image.SCALE_DEFAULT);
		ImageIcon iconLabel1 = new ImageIcon(icon11);
		JLabel labelIcon1 = new JLabel(iconLabel1);
		add(labelIcon1);
		labelIcon1.setBounds(470, 90, 400, 310);
		labelIcon1.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");
		
		
		/*
		JPanel area1 = new JPanel();
		JScrollPane scrollArea = new JScrollPane(area1);
		add(scrollArea);
		scrollArea.setBounds(10,400,550,210);*/
		MarqueePanel marquee = new MarqueePanel();
		add(marquee);
		ImageIcon b3 = new ImageIcon("b3.jpg");
		Image imgb3 = b3.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb3 = new ImageIcon(imgb3);
		JLabel labelb3 = new JLabel(iconb3);
		
		ImageIcon b4 = new ImageIcon("b4.jpg");
		Image imgb4 = b4.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb4 = new ImageIcon(imgb4);
		JLabel labelb4 = new JLabel(iconb4);
		
		ImageIcon b5 = new ImageIcon("b5.jpg");
		Image imgb5 = b5.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb5 = new ImageIcon(imgb5);
		JLabel labelb5 = new JLabel(iconb5);
		
		ImageIcon b6 = new ImageIcon("b6.jpg");
		Image imgb6 = b6.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb6 = new ImageIcon(imgb6);
		JLabel labelb6 = new JLabel(iconb6);
		
		ImageIcon b7 = new ImageIcon("b7.jpg");
		Image imgb7 = b7.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb7 = new ImageIcon(imgb7);
		JLabel labelb7 = new JLabel(iconb7);
		
		ImageIcon b8 = new ImageIcon("b8.jpg");
		Image imgb8 = b8.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb8 = new ImageIcon(imgb8);
		JLabel labelb8 = new JLabel(iconb8);
		
		ImageIcon b9 = new ImageIcon("b9.jpg");
		Image imgb9 = b9.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb9 = new ImageIcon(imgb9);
		JLabel labelb9 = new JLabel(iconb9);
		
		ImageIcon b10 = new ImageIcon("b10.jpg");
		Image imgb10 = b10.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb10 = new ImageIcon(imgb10);
		JLabel labelb10 = new JLabel(iconb10);
		
		
		marquee.add(labelb3);
		marquee.add(labelb4);
		marquee.add(labelb5);
		marquee.add(labelb6);
		marquee.add(labelb7);
		marquee.add(labelb8);
		marquee.add(labelb9);
		marquee.add(labelb10);
		//marquee.setBounds(350, 420, 500, 200);
		marquee.setBounds(10,400,550,210);
		marquee.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");

	
		
		
		
		
		
		
		
		
		
		
		
		
		JLabel labelLog = new JLabel("Username: ");
		add(labelLog);
		labelLog.setBounds(610, 420, 150, 30);
		labelLog.setForeground(Color.white);
		labelLog.setFont(new Font("",Font.BOLD,20));
		
		JTextField fieldLog = new JTextField(10);
		add(fieldLog);
		fieldLog.setBounds(720, 420, 100, 30);
		
		JLabel labelLog1 = new JLabel("Password: ");
		add(labelLog1);
		labelLog1.setBounds(610, 460, 150, 30);
		labelLog1.setForeground(Color.white);
		labelLog1.setFont(new Font("",Font.BOLD,20));
		
		JPasswordField fieldLog1 = new JPasswordField(10);
		add(fieldLog1);
		fieldLog1.setBounds(720, 460, 100, 30);
		
		
		JButton btnLogin = new JButton("Login");
		add(btnLogin);
		btnLogin.setBounds(750, 500, 70, 30);
		
		JLabel others = new JLabel("<html>Not yet a member?<br> Please register.</html>");
		add(others);
		others.setBounds(610, 570, 200, 30);
		others.setForeground(Color.white);
		
		JButton btnReg = new JButton("Register");
		add(btnReg);
		btnReg.setBounds(730, 570, 90, 30);
		
		
		
		
		JPanel left = new JPanel();
		add(left);
		left.setBackground(Color.blue);
		left.setBounds(590, 400, 5, 210);
		
		JPanel right = new JPanel();
		add(right);
		right.setBackground(Color.blue);
		right.setBounds(860, 400, 5, 210);
		
		JPanel up = new JPanel();
		add(up);
		up.setBackground(Color.blue);
		up.setBounds(590, 400, 275, 5);
		
		JPanel panelLog3 = new JPanel();
		add(panelLog3);
		panelLog3.setBackground(Color.blue);
		panelLog3.setBounds(590, 605, 275, 5);
		

		home.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Index();
			        dispose();
			    }
		});
		
		about.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new AboutUs1();
			        dispose();
			    }
		});
	
		
		btnLogin.addActionListener(new ActionListener() {  
		    public void actionPerformed(ActionEvent evt) { 
		    	try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro", "root", "");
					Statement stm = conn.createStatement();
					String sql = "Select * from customers where username='"+fieldLog.getText()+"' and password='"+fieldLog1.getText().toString()+"'";
					ResultSet myResult = stm.executeQuery(sql);
					if(myResult.next()) {
						JOptionPane.showMessageDialog(null, "Login Successful");
						new Home();
						dispose();
					}
					else {
						JOptionPane.showMessageDialog(null, "Wrong Username or Password");
					}
				}
				catch(Exception b) {
					System.out.println(b);
				}
		    }  
		});
		
		
		btnReg.addActionListener(new ActionListener() {  
		    public void actionPerformed(ActionEvent evt) { 
		        new Register();
		        dispose();
		    }  
		});
		
		
	
		service.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 JOptionPane.showMessageDialog(null, "Please Login");
			    }
		});
	
		

	

	}


	
	public void actionPerformed(ActionEvent e) {
		

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

