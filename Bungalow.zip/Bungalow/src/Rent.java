import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.imageio.event.IIOReadUpdateListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Rent extends JFrame implements ActionListener, MouseListener {
	JMenuBar mainMenu = new JMenuBar();
	JMenu home = new JMenu("HOME");
	JMenu service = new JMenu("SERVICE");
	JMenuItem buy = new JMenuItem("HOUSES");
	//JMenuItem rent = new JMenuItem("RENT");
	JMenu about = new JMenu("ABOUT US");
	Font fontsize = new Font("",Font.BOLD,20);
	ImageIcon logo = new ImageIcon("ogteck_logo.png");
	ImageIcon logout = new ImageIcon("logout.jpg");
	MarqueeLabel marquee = new MarqueeLabel("Welcome to Retechpro Support and Services Ltd. We render all form of services in the field of technology. We are located at Famagusta, North Cyprus.", MarqueeLabel.RIGHT_TO_LEFT,20);
	
	ImageIcon icon0 = new ImageIcon("b0.jpg");
	ImageIcon icon1 = new ImageIcon("b1.jpg");
	

	public static void main(String[] args) {
		Rent Rent11 = new Rent();

	}

	public Rent() {
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);

		JPanel menuPanel = new JPanel();
		setJMenuBar(mainMenu);
		add(menuPanel);
		menuPanel.add(mainMenu);
		mainMenu.add(home);
		mainMenu.add(service);
		mainMenu.add(about);
		service.add(buy);
		//service.addSeparator();
		//service.add(rent);
		menuPanel.setBounds(80,0,820,40);
		home.setFont(fontsize);
		service.setFont(fontsize);
		about.setFont(fontsize);
		buy.setFont(fontsize);
		//rent.setFont(fontsize);                 
		
		add(marquee);
		marquee.setBounds(0, 40, 1450, 30);
		marquee.setForeground(Color.white);
		marquee.setFont(fontsize); 
		
		
		Image logoutImg = logout.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon logoutIcon = new ImageIcon(logoutImg);
		JLabel logoutLabel = new JLabel(logoutIcon);
		menuPanel.add(logoutLabel);
		
		
		Image logoImg = logo.getImage().getScaledInstance(80, 40, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel logoLabel = new JLabel(logoIcon);
		add(logoLabel);
		logoLabel.setBounds(0, 0, 80, 40);
		

		
		JLabel bungalowlist = new JLabel("Bungalow:");
		add(bungalowlist);
		bungalowlist.setBounds(50,100,100,40);
		bungalowlist.setFont(fontsize);
		bungalowlist.setForeground(Color.white);
		
		
		
		JComboBox listCombo = new JComboBox();
		add(listCombo);
		listCombo.setBounds(170,100,250,40);
		listCombo.addItem("Please select choice Bungalow");
		listCombo.addItem("B1");
		listCombo.addItem("B2");
		//listCombo.addItem("B3");
		//listCombo.addItem("B4");
		//listCombo.addItem("B5");
		//listCombo.addItem("B6");
		//listCombo.addItem("B7");
		//listCombo.addItem("B8");
		//listCombo.addItem("B9");
		//listCombo.addItem("B10");
		//listCombo.addItem("B11");
		//listCombo.addItem("B12");
	
		
		JButton btn = new JButton("CHOOSE");
		add(btn);
		btn.setBounds(200,400,150,40);
		
		
		listCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (listCombo.getSelectedItem()=="B1") {
					ImageIcon iconB1 = new ImageIcon("b1.jpg");
					Image imgB1 = iconB1.getImage().getScaledInstance(450, 200, Image.SCALE_DEFAULT);
					ImageIcon B1icon = new ImageIcon(imgB1);
					JLabel labelB1 = new JLabel(B1icon);
					add(labelB1);
					labelB1.setBounds(470,80,410,200);
					
					ImageIcon iconbb = new ImageIcon("aa0.jpg");
					Image imgbb = iconbb.getImage().getScaledInstance(200, 100, Image.SCALE_DEFAULT);
					ImageIcon B1iconbb = new ImageIcon(imgbb);
					JLabel labelbb = new JLabel(B1iconbb);
					add(labelbb);
					labelbb.setBounds(470,290,200,100);
					
					ImageIcon iconaa1 = new ImageIcon("aa1.jpg");
					Image imgaa1 = iconaa1.getImage().getScaledInstance(200, 100, Image.SCALE_DEFAULT);
					ImageIcon B1iconaa1 = new ImageIcon(imgaa1);
					JLabel labelaa1 = new JLabel(B1iconaa1);
					add(labelaa1);
					labelaa1.setBounds(680,290,200,100);
					
					ImageIcon iconaa2 = new ImageIcon("aa2.jpg");
					Image imgaa2 = iconaa2.getImage().getScaledInstance(200, 100, Image.SCALE_DEFAULT);
					ImageIcon B1iconaa = new ImageIcon(imgaa2);
					JLabel labelaa2 = new JLabel(B1iconaa);
					add(labelaa2);
					labelaa2.setBounds(470,400,200,100);
					
					ImageIcon iconaa3 = new ImageIcon("aa3.jpg");
					Image imgaa3 = iconaa3.getImage().getScaledInstance(200, 100, Image.SCALE_DEFAULT);
					ImageIcon B1iconaa3 = new ImageIcon(imgaa3);
					JLabel labelaa3 = new JLabel(B1iconaa3);
					add(labelaa3);
					labelaa3.setBounds(680,400,200,100);
					
					
					
					JLabel labelDetails0 = new JLabel("<html>B1 BUNGALOW<br><br><p style=\"font-family:monospace\">Color: white<br>Roofing: Brick bats lime Concrete<br>"
							+ "Price: $5000 </p></html>");
					add(labelDetails0);
					labelDetails0.setBounds(150, 150, 300, 200);
					labelDetails0.setForeground(Color.white);
					labelDetails0.setFont(new Font("",Font.BOLD,20));
					
					
				}
				
				else
					JOptionPane.showMessageDialog(null, "CURRENTLY UNAVAILABLE");
			
			/*	else if(listCombo.getSelectedItem()=="B2") {
					
					ImageIcon iconB2 = new ImageIcon("b2.jpg");
					Image imgB2 = iconB2.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
					ImageIcon B1icon2 = new ImageIcon(imgB2);
					JLabel labelB2 = new JLabel(B1icon2);
					add(labelB2);
					labelB2.setBounds(500,100,300,300);
					
					
					
				}
				else if(listCombo.getSelectedItem()=="B3") {
					ImageIcon iconB3 = new ImageIcon("b3.jpg");
					Image imgB3 = iconB3.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
					ImageIcon B1icon3 = new ImageIcon(imgB3);
					JLabel labelB3 = new JLabel(B1icon3);
					add(labelB3);
					labelB3.setBounds(400,100,300,300);
					pack();
					
				}*/
				
				
			
			
				btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						 String[] s = new String[]{"B1"};
						new Form(s);
						dispose();
					}
				});
				
				
				
				
				
				
				
				
			}
	
		});
		
		
	
		

		home.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Home();
			        dispose();
			    }
		});
		
		about.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new AboutUs();
			        dispose();
			    }
		});
	
		
		logoutLabel.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Index();
			        dispose();
			    }
		});
	
		
		
	
	
	
		

	

	}


	
	public void actionPerformed(ActionEvent e) {
		

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

