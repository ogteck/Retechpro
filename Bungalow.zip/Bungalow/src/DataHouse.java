import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;

public class DataHouse extends JFrame{
	JMenuBar mainMenu = new JMenuBar();
	JMenu home = new JMenu("HOME");
	JMenu service = new JMenu("SERVICE");
	JMenuItem admin = new JMenuItem("Admin");
	JMenuItem rent = new JMenuItem("HOUSES");
	JMenu about = new JMenu("ABOUT US");
	Font fontsize = new Font("",Font.BOLD,20);
	ImageIcon logo = new ImageIcon("ogteck_logo.png");
	ImageIcon logout = new ImageIcon("logout.jpg");
	JTabbedPane allTab = new JTabbedPane(JTabbedPane.VERTICAL);
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	
		JTable table = new JTable();
	    JTable table1 = new JTable();
	    JTable table2 = new JTable();
	    JTable table3 = new JTable();
	    JButton refresh = new JButton("REFRESH");
	    JButton refresh1 = new JButton("REFRESH");
	    JButton refresh2 = new JButton("REFRESH");
	    JButton searchBtn = new JButton("SEARCH");
	    JScrollPane stable = new JScrollPane(table);
	    JScrollPane stable1 = new JScrollPane(table1);
	    JScrollPane stable2 = new JScrollPane(table2);
	    JScrollPane stable3 = new JScrollPane(table3);
	    
	
	public static void main (String [] args) {
		DataHouse DataHouse77 = new DataHouse();
	}
	
	public DataHouse() {
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);
		
		
		JPanel menuPanel = new JPanel();
		setJMenuBar(mainMenu);
		add(menuPanel);
		menuPanel.add(mainMenu);
		mainMenu.add(home);
		mainMenu.add(service);
		mainMenu.add(about);
		service.add(rent);
		service.addSeparator();
		service.add(admin);
		
		menuPanel.setBounds(80,0,820,40);
		home.setFont(fontsize);
		service.setFont(fontsize);
		about.setFont(fontsize);
		admin.setFont(fontsize);
		rent.setFont(fontsize);                 
		
		
		Image logoutImg = logout.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon logoutIcon = new ImageIcon(logoutImg);
		JLabel logoutLabel = new JLabel(logoutIcon);
		menuPanel.add(logoutLabel);
		
		
		Image logoImg = logo.getImage().getScaledInstance(80, 40, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel logoLabel = new JLabel(logoIcon);
		add(logoLabel);
		logoLabel.setBounds(0, 0, 80, 40);
		
		
		
		add(allTab);
		allTab.setBounds(50, 50, 800, 550);
		allTab.addTab("List of Bungalow", p1);
		allTab.addTab("Customers", p2);
		allTab.addTab("Search Customer", p3);
		allTab.addTab("List of Booking", p4);
		allTab.setFont(new Font("",Font.BOLD,20));
		
		
	
		
		
		
		
		//add(p1);
		p1.setLayout(null);
		p1.setBackground(Color.blue);
		p1.add(refresh1);
		refresh1.setBounds(350,10,100,30);
		p1.add(stable1);
		stable1.setBounds(50,50,700,450);
		
		refresh1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{  
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro","root","");   
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select * from bungalow");
					table1.setModel(DbUtils.resultSetToTableModel(rs));
					while(rs.next()) 
					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)
					+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9)+"  "+rs.getString(10));  
					
					
					con.close();  
					}
				catch(Exception es){ 
					System.out.println(es);
					
					}

				
			}
		});
		
		
		
		//add(p2);
		p2.setLayout(null);
		p2.setBackground(Color.green);
		p2.add(refresh2);
		refresh2.setBounds(350,10,100,30);
		p2.add(stable2);
		stable2.setBounds(50,50,700,450);
		refresh2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{  
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro","root","");   
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select * from customers");
					table2.setModel(DbUtils.resultSetToTableModel(rs));
					while(rs.next()) 
					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)
					+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9)+"  "+rs.getString(10));  
					
					
					con.close();  
					}
				catch(Exception es){ 
					System.out.println(es);
				
					}

				
			}
		});
		
		//add(p3);
		JTextField search = new JTextField(20);
		p3.setLayout(null);
		p3.setBackground(Color.pink);
		p3.add(search);
		search.setBounds(140,10,200,30);
	
		p3.add(searchBtn);
		searchBtn.setBounds(350,10,100,30);
		p3.add(stable3);
		stable3.setBounds(50,50,700,200);
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String value = search.getText();
			
				
				try{  
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro","root","");   
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select * from customers Where surname='"+value+"'");
					table3.setModel(DbUtils.resultSetToTableModel(rs));
					while(rs.next()) 
					//System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)
					//+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9)+"  "+rs.getString(10));  
						System.out.println(rs.getString(1));
					
					con.close();  
					}
				catch(Exception es){ 
					System.out.println(es);
					}

				
			}
		});
		
		
		/*
		JLabel assign = new JLabel("Assign Bungalow to selected customer below.");
		p3.add(assign);
		assign.setBounds(50,270,500,40);
		assign.setFont(new Font("",Font.BOLD,20));
		
		JComboBox listCombo1 = new JComboBox();
		p3.add(listCombo1);
		listCombo1.setBounds(170,100,250,40);
		listCombo1.addItem("Assign Bungalow");
		listCombo1.addItem("B1");
		listCombo1.addItem("B2");
		listCombo1.setBounds(50,330,100,40);
		
		JButton assigBtn = new JButton("Assign Bungalow");
		p3.add(assigBtn);
		assigBtn.setBounds(50,390,150,40);
		
		assigBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(listCombo1.getSelectedItem()=="b1") {
					
				}
			}
		});
		*/
		
		
		
		
		
		//add(p4);
		p4.setLayout(null);
		p4.setBackground(Color.white);
		p4.add(refresh);
		refresh.setBounds(350,10,100,30);
		p4.add(stable);
		stable.setBounds(50,50,700,450);
		refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{  
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro","root","");   
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select bungalowName,surname,firstName,dateTime from reservation");
					table.setModel(DbUtils.resultSetToTableModel(rs));
					while(rs.next()) 
					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)
					+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9)+"  "+rs.getString(10));  
					
					
					con.close();  
					}
				catch(Exception es){ 
					System.out.println(es);
			
					}

				
			}
		});
		
		admin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new Admin();
				dispose();
			}
		});
		
		
		
		rent.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new Rent();
				dispose();
			}
		});
		
		

		home.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Home();
			        dispose();
			    }
		});
		
		about.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new AboutUs();
			        dispose();
			    }
		});
	
		
		logoutLabel.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Index();
			        dispose();
			    }
		});
	
	}

}
