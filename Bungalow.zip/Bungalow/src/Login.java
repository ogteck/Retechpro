import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame {
	JLabel labelUser = new JLabel("Username:");
	JLabel labelPassword = new JLabel("Password:");
	JTextField fieldUser = new JTextField(30);
	JPasswordField fieldPassword = new JPasswordField(40);
	JButton register = new JButton("Register");
	JButton login = new JButton("Login");
	JLabel not = new JLabel("Not yet Registered ?   click ");

	public static void main(String[] args) {
		Login LoginLogin = new Login();

	}

	public Login() {
	
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(700,500));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Login Page");
		setLocationRelativeTo(null);
		setVisible(true);



		add(labelUser);
		add(labelPassword);
		add(fieldUser);
		add(fieldPassword);
		add(not);
		add(register);
		add(login);




		ImageIcon loginIcon1 = new ImageIcon("login.jpg");
		Image loginImage1 = loginIcon1.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon loginImg1 = new ImageIcon(loginImage1);
		JLabel labelLogin1 = new JLabel(loginImg1);
		add(labelLogin1);
		labelLogin1.setBounds(280, 40, 150, 150);

		labelUser.setBounds(150, 200, 100, 30);
		labelPassword.setBounds(150, 250, 100, 30);
		fieldUser.setBounds(250, 200, 200, 30);
		fieldPassword.setBounds(250, 250, 200, 30);

		login.setBounds(300,300,150,40);
		login.setFont(new Font("",Font.BOLD,30));
		not.setBounds(150,380,200,30);
		register.setBounds(305,380,90,30);


		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro", "root", "");
					Statement stm = conn.createStatement();
					
					String sql = "Select * from customers where username='"+fieldUser.getText()+"' and password='"+fieldPassword.getText().toString()+"'";

					String myUser = fieldUser.getText();
					String myPass = fieldPassword.getText();
					if(myUser.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Please enter Username");
					}
					else {
						if(myPass.isEmpty()) {
							JOptionPane.showMessageDialog(null, "Please enter Password");
						}
						else {
							ResultSet myResult = stm.executeQuery(sql);
							if(myResult.next()) {
					
								JOptionPane.showMessageDialog(null, "Login Successful");
								new Home();
								dispose();
							
							}
							else {
								JOptionPane.showMessageDialog(null, "Wrong Username or Password");
							}
						}
					}











				}

				catch(Exception b) {
					System.out.println(b);
				}

			}
		});

		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Register();
				dispose();

			}
		});


	}

}
