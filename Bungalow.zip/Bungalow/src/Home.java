import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Home extends JFrame implements ActionListener, MouseListener {
	JMenuBar mainMenu = new JMenuBar();
	JMenu home = new JMenu("HOME");
	JMenu service = new JMenu("SERVICE");
	JMenuItem admin = new JMenuItem("Admin");
	JMenuItem rent = new JMenuItem("HOUSES");
	JMenu about = new JMenu("ABOUT US");
	Font fontsize = new Font("",Font.BOLD,20);
	ImageIcon logo = new ImageIcon("ogteck_logo.png");
	ImageIcon logout = new ImageIcon("logout.jpg");
	MarqueeLabel marquee = new MarqueeLabel("Welcome to Retechpro Support and Services Ltd. We render all form of services in the field of technology. We are located at Famagusta, North Cyprus.", MarqueeLabel.RIGHT_TO_LEFT,20);
	
	ImageIcon icon0 = new ImageIcon("b0.jpg");
	ImageIcon icon1 = new ImageIcon("b1.jpg");
	

	public static void main(String[] args) {
		Home Home33 = new Home();

	}

	public Home() {
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);

		JPanel menuPanel = new JPanel();
		setJMenuBar(mainMenu);
		add(menuPanel);
		menuPanel.add(mainMenu);
		mainMenu.add(home);
		mainMenu.add(service);
		mainMenu.add(about);
		service.add(rent);
		service.addSeparator();
		service.add(admin);
		
		menuPanel.setBounds(80,0,820,40);
		home.setFont(fontsize);
		service.setFont(fontsize);
		about.setFont(fontsize);
		admin.setFont(fontsize);
		rent.setFont(fontsize);                 
		
		add(marquee);
		marquee.setBounds(0, 40, 1450, 30);
		marquee.setForeground(Color.white);
		marquee.setFont(fontsize); 
		
		//JMenuItem blankB = new JMenuItem("                                                                                                                                              ");
		//menuPanel.add(blankB);
		
		Image logoutImg = logout.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon logoutIcon = new ImageIcon(logoutImg);
		JLabel logoutLabel = new JLabel(logoutIcon);
		menuPanel.add(logoutLabel);
		
		
		Image logoImg = logo.getImage().getScaledInstance(80, 40, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel logoLabel = new JLabel(logoIcon);
		add(logoLabel);
		logoLabel.setBounds(0, 0, 80, 40);
		
		Image icon00 = icon0.getImage().getScaledInstance(400, 200, Image.SCALE_DEFAULT);
		ImageIcon iconLabel0 = new ImageIcon(icon00);
		JLabel labelIcon0 = new JLabel(iconLabel0);
		add(labelIcon0);
		labelIcon0.setBounds(10, 90, 400, 200);
		labelIcon0.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");
	
		JLabel labelDetails1 = new JLabel("<html><p style=\"font-family:monospace; color:orange\">Choose From a Wide Range of Houses.</p><br>"
				+ "Craftsman & Bungalow Houses.<br>"
				+ "Small House.s<br>"
				+ "Transitional Bungalows.<br>"
				+ "Bungalow with Detached Garage.</html>");
		add(labelDetails1);
		labelDetails1.setBounds(460, 60, 500, 200);
		labelDetails1.setForeground(Color.white);
		labelDetails1.setFont(new Font("",Font.BOLD,20));
		
		JButton contact = new JButton("Contact Us");
		add(contact);
		contact.setBounds(550,250,100,40);
		
		contact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AboutUs();
				dispose();
				
			}
		});
		
		JPanel allPlan = new JPanel();
		add(allPlan);
		JPanel allPlans = new JPanel();
		add(allPlans);
		JLabel plan = new JLabel ("You Want to Buy or Rent Your Dream Home? We Have your dream ready.");
		allPlan.add(plan);
		//plan.setBounds(70,330,800,40);
		plan.setFont(new Font("",Font.BOLD,20));
		allPlan.setBackground(Color.white);
		allPlan.setBounds(50,330,800,40);
		JLabel plans = new JLabel ("We are not a house plan seller. We are house seller");
		allPlans.add(plans);
		allPlans.setBackground(Color.white);
		allPlans.setBounds(170,365,500,40);
		plans.setFont(new Font("",Font.BOLD,15));
		
		
		JLabel listOf = new JLabel ("<html>You can view our list of houses through the service menu<br><br> or visit </html>");
		add(listOf);
		listOf.setBounds(50, 410, 250, 150);
		listOf.setFont(new Font("",Font.BOLD,15));
		listOf.setForeground(Color.white);
		
		JButton ofList = new JButton("HOUSES");
		add(ofList);
		ofList.setBounds(110,500,90,30);
		ofList.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new Rent();
				dispose();
			}
		});
		
		
		MarqueePanel marquee = new MarqueePanel();
		add(marquee);
		ImageIcon b3 = new ImageIcon("b3.jpg");
		Image imgb3 = b3.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb3 = new ImageIcon(imgb3);
		JLabel labelb3 = new JLabel(iconb3);
		
		ImageIcon b4 = new ImageIcon("b4.jpg");
		Image imgb4 = b4.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb4 = new ImageIcon(imgb4);
		JLabel labelb4 = new JLabel(iconb4);
		
		ImageIcon b5 = new ImageIcon("b5.jpg");
		Image imgb5 = b5.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb5 = new ImageIcon(imgb5);
		JLabel labelb5 = new JLabel(iconb5);
		
		ImageIcon b6 = new ImageIcon("b6.jpg");
		Image imgb6 = b6.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb6 = new ImageIcon(imgb6);
		JLabel labelb6 = new JLabel(iconb6);
		
		ImageIcon b7 = new ImageIcon("b7.jpg");
		Image imgb7 = b7.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb7 = new ImageIcon(imgb7);
		JLabel labelb7 = new JLabel(iconb7);
		
		ImageIcon b8 = new ImageIcon("b8.jpg");
		Image imgb8 = b8.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb8 = new ImageIcon(imgb8);
		JLabel labelb8 = new JLabel(iconb8);
		
		ImageIcon b9 = new ImageIcon("b9.jpg");
		Image imgb9 = b9.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb9 = new ImageIcon(imgb9);
		JLabel labelb9 = new JLabel(iconb9);
		
		ImageIcon b10 = new ImageIcon("b10.jpg");
		Image imgb10 = b10.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon iconb10 = new ImageIcon(imgb10);
		JLabel labelb10 = new JLabel(iconb10);
		
		
		marquee.add(labelb3);
		marquee.add(labelb4);
		marquee.add(labelb5);
		marquee.add(labelb6);
		marquee.add(labelb7);
		marquee.add(labelb8);
		marquee.add(labelb9);
		marquee.add(labelb10);
		marquee.setBounds(350, 420, 500, 200);
		marquee.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");

	
		
		
		admin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new Admin();
				dispose();
			}
		});
		
		
		
		rent.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new Rent();
				dispose();
			}
		});
		
		

		home.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Home();
			        dispose();
			    }
		});
		
		about.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new AboutUs();
			        dispose();
			    }
		});
	
		
		logoutLabel.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Index();
			        dispose();
			    }
		});
	
		
		
	
	
	
		

	

	}


	
	public void actionPerformed(ActionEvent e) {
		

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

