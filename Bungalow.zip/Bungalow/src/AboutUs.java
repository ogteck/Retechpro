import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;


class MyMarquee extends JLabel {  
	public static int LEFT_TO_RIGHT = 1;  
	public static int RIGHT_TO_LEFT = 2;  
	String text;  
	int Option;  
	int Speed;  
	public MyMarquee(String text, int Option, int Speed) {  
		this.Option = Option;  
		this.Speed = Speed;  
		this.setText(text);  
	}  
	@Override  
	protected void paintComponent(Graphics g) {  
		if (Option == LEFT_TO_RIGHT) {  
			g.translate((int) ((System.currentTimeMillis() / Speed) % (getWidth() * 2) - getWidth()), 0);  
		} else if (Option == RIGHT_TO_LEFT) {  
			g.translate((int) (getWidth() - (System.currentTimeMillis() / Speed) % (getWidth() * 2)), 0);  
		}  
		super.paintComponent(g);  
		repaint(5);  
	}  
}



public class AboutUs extends JFrame implements ActionListener, MouseListener{
	JMenuBar mainMenu = new JMenuBar();
	JMenu home = new JMenu("HOME");
	JMenu service = new JMenu("SERVICE");
	JMenu about = new JMenu("ABOUT US");
	//JMenuItem buy = new JMenuItem("BUY");
	JMenuItem rent = new JMenuItem("HOUSES");
	Font fontsize = new Font("",Font.BOLD,20);
	ImageIcon logo = new ImageIcon("ogteck_logo.png");
	JTabbedPane myPane = new JTabbedPane(JTabbedPane.VERTICAL);
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	ImageIcon logout = new ImageIcon("logout.jpg");
	MarqueeLabel marquee = new MarqueeLabel("Welcome to Retechpro Support and Services Ltd. We render all form of services in the field of technology. We are located at Famagusta, North Cyprus.", MarqueeLabel.RIGHT_TO_LEFT,20);
	
	ImageIcon imgIc = new ImageIcon("ib.jpg");
	Image forIcon = imgIc.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
	ImageIcon imgIcon = new ImageIcon(forIcon);
	JLabel iconLabel = new JLabel(imgIcon);
	
	public static void main(String[] args) {
		AboutUs AboutUs77 = new AboutUs();

	}

	AboutUs(){
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(900,700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Support and Services Ltd.");
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.gray);
		setVisible(true);


		JPanel menuPanel = new JPanel();
		setJMenuBar(mainMenu);
		add(menuPanel);
		menuPanel.add(mainMenu);
		mainMenu.add(home);
		mainMenu.add(service);
		mainMenu.add(about);
		//service.add(buy);
		service.addSeparator();
		service.add(rent);
		menuPanel.setBounds(80,0,820,40);
		home.setFont(fontsize);
		service.setFont(fontsize);
		about.setFont(fontsize);
		//buy.setFont(fontsize);
		rent.setFont(fontsize);
		
		add(marquee);
		marquee.setBounds(0, 40, 1450, 30);
		marquee.setForeground(Color.white);
		marquee.setFont(fontsize);

		add(myPane);
		myPane.addTab("About Retechpro", p1);
		myPane.addTab("About System Designer", p2);
		myPane.setBounds(5,100,870,510);
		myPane.setFont(fontsize);
		
		Image logoutImg = logout.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon logoutIcon = new ImageIcon(logoutImg);
		JLabel logoutLabel = new JLabel(logoutIcon);
		menuPanel.add(logoutLabel);

		Image logoImg = logo.getImage().getScaledInstance(80, 40, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel logoLabel = new JLabel(logoIcon);
		add(logoLabel);
		logoLabel.setBounds(0, 0, 80, 40);


		home.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				new Home();
				dispose();
			}
		});

		about.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				new AboutUs();
				dispose();
			}
		});

		logoutLabel.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 new Index();
			        dispose();
			    }
		});
		
		rent.addActionListener(new ActionListener() {
	
			public void actionPerformed(ActionEvent e) {
				new Rent();
				dispose();
				
			}
		});

		p1.setLayout(null);
		//p1.setVisible(true);
		p1.setBackground(Color.red);
		p1.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");
		JLabel Companyname = new JLabel("<html><center>Retechpro Support and Services Ltd.</center></html>");
		JLabel Companyinfo = new JLabel("<html><p>WE SPECIALIZES IN:</p> <br> \fSale of Houses<br>\fWeb & System Design<br>"
				+ "\fHouse Rentals<br>\fTechnical Support<br>"
				+ " \fApp & Software development<br> \fSystem security<br> \fSystem and Network Configuration<br>"
				+ "\fBusiness Analysis<br>\fData Management<br>\fSystem Administration and Analysis</html>");
		JLabel Companyaddress = new JLabel("<html><p>ADDRESS:</p> <br> Famagusta,<br> North-Cyprus,<br>Turkish Republic of Northern Cyprus (TRNC).");
		
		p1.add(Companyname);
		Companyname.setBounds(200,40,400,60);
		Companyname.setForeground(Color.white);
		Companyname.setFont(new Font("Rockwell Extra Bold",Font.BOLD,30));
		
		p1.add(Companyinfo);
		Companyinfo.setBounds(50,130,400,300);
		Companyinfo.setForeground(Color.white);
		Companyinfo.setFont(new Font("Goudy Old Style",Font.BOLD,20));
		
		p1.add(Companyaddress);
		Companyaddress.setBounds(500,90,400,200);
		Companyaddress.setForeground(Color.white);
		Companyaddress.setFont(new Font("Goudy Old Style",Font.BOLD,20));

		p2.setLayout(null);
		//p2.setVisible(true);
		p2.setBackground(Color.blue);
		JLabel name = new JLabel("<html><mark>Name: Oghogho Agbaman Napoleon</mark></html>");
		JLabel address = new JLabel("Address: Karafil Market, Haspolat");
		JLabel phone = new JLabel("Phone Number: +905428578932, +2347067385024");
		JLabel email = new JLabel("Email: oghoghonapo@gmail.com napoleonog@yahoo.com");
	
		p2.add(name);
		name.setBounds(10,30,400,40);
		name.setForeground(Color.white);
		name.setFont(fontsize);
		p2.add(address);
		address.setBounds(10,80,400,40);
		address.setForeground(Color.white);
		address.setFont(fontsize);
		p2.add(phone);
		phone.setBounds(10,130,500,40);
		phone.setForeground(Color.white);
		phone.setFont(fontsize);
		p2.add(email);
		email.setBounds(10,180,600,40);
		email.setForeground(Color.white);
		email.setFont(fontsize);
		
		p2.add(iconLabel);
		iconLabel.setBounds(580, 40, 300, 300);
		iconLabel.setToolTipText("DESIGNED BY: OGHOGHO NAPOLEON");

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
