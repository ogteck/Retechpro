import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MarqueePanel extends JPanel
	implements ActionListener, AncestorListener, WindowListener
{
	protected boolean paintChildren;
	protected boolean scrollingPaused;
	protected int scrollOffset;
	protected int wrapOffset;

	private int preferredWidth = -1;
	private int scrollAmount;
	private int scrollFrequency;
	private boolean wrap = false;
	private int wrapAmount = 50;

	private Timer timer = new Timer(1000, this);

	
	public MarqueePanel()
	{
		this(5, 5);
	}

	public MarqueePanel(int scrollFrequency, int scrollAmount)
	{
		setScrollFrequency( scrollFrequency );
		setScrollAmount( scrollAmount );
		setLayout( new BoxLayout(this, BoxLayout.X_AXIS) );
		addAncestorListener( this );
	}


	public void paintChildren(Graphics g)
	{
		
		if (! paintChildren) return;

		Graphics2D g2d = (Graphics2D)g;
		g2d.translate(-scrollOffset, 0);
		super.paintChildren(g);
		g2d.translate(scrollOffset, 0);


		if (isWrap())
		{
			wrapOffset = scrollOffset - super.getPreferredSize().width - wrapAmount;
			g2d.translate(-wrapOffset, 0);
			super.paintChildren(g);
			g2d.translate(wrapOffset, 0);
		}
	}

		public Dimension getPreferredSize()
	{
		Dimension d = super.getPreferredSize();

		d.width = (preferredWidth == -1) ? d.width / 2 : preferredWidth;

		return d;
	}

	
	public Dimension getMinimumSize()
	{
		return getPreferredSize();
	}

	public int getPreferredWidth()
	{
		return preferredWidth;
	}

	
	public void setPreferredWidth(int preferredWidth)
	{
		this.preferredWidth = preferredWidth;
		revalidate();
	}

	public int getScrollAmount()
	{
		return scrollAmount;
	}

	public void setScrollAmount(int scrollAmount)
	{
		this.scrollAmount = scrollAmount;
	}

	
	public int getScrollFrequency()
	{
		return scrollFrequency;
	}

	public void setScrollFrequency(int scrollFrequency)
	{
		this.scrollFrequency = scrollFrequency;

		int delay = 500 / scrollFrequency;
		timer.setInitialDelay( delay );
		timer.setDelay( delay );
	}


	public boolean isWrap()
	{
		return wrap;
	}


	public void setWrap(boolean wrap)
	{
		this.wrap = wrap;
	}

	
	public int getWrapAmount()
	{
		return wrapAmount;
	}

	
	public void setWrapAmount(int wrapAmount)
	{
		this.wrapAmount = wrapAmount;
	}

	
	public void startScrolling()
	{
		paintChildren = true;
		scrollOffset =  - getSize().width;

		timer.start();
	}

	public void stopScrolling()
	{
		timer.stop();
		paintChildren = false;
		repaint();
	}

	public void pauseScrolling()
	{
		if (timer.isRunning())
		{
			timer.stop();
			scrollingPaused = true;
		}
	}


	public void resumeScrolling()
	{
		if (scrollingPaused)
		{
			timer.restart();
			scrollingPaused = false;
		}
	}

	public void actionPerformed(ActionEvent ae)
	{
		scrollOffset = scrollOffset + scrollAmount;
		int width = super.getPreferredSize().width;

		if (scrollOffset > width)
		{
			scrollOffset = isWrap() ? wrapOffset + scrollAmount : - getSize().width;
		}

		repaint();
	}


	public void ancestorAdded(AncestorEvent e)
	{
		SwingUtilities.windowForComponent( this ).addWindowListener( this );
	}

	public void ancestorMoved(AncestorEvent e) {}
	public void ancestorRemoved(AncestorEvent e) {}



	public void windowClosed(WindowEvent e)
	{
		stopScrolling();
	}

	public void windowClosing(WindowEvent e)
	{
		stopScrolling();
	}


	public void windowDeiconified(WindowEvent e)
	{
		resumeScrolling();
	}

	public void windowIconified(WindowEvent e)
	{
		pauseScrolling();
	}

	public void windowOpened(WindowEvent e)
	{
		startScrolling();
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
}