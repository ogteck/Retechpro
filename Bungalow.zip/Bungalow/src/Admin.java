import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class Admin extends JFrame {
	JLabel pass = new JLabel("PASS-CODE:");
	JPasswordField pass1 = new JPasswordField(20);
	JButton enter = new JButton("ENTER");
	

	public static void main(String[] args) {
		Admin Admin76 = new Admin();

	}
	
	
	public Admin() {
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(300,300));
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("ADMIN GATEWAY");
		setLocationRelativeTo(null);
		
		
		
		JLabel labelImg = new JLabel();
		ImageIcon iconLog = new ImageIcon("admin.jpg");
		labelImg.setIcon(iconLog);
		add(labelImg);
		labelImg.setBounds(90, 5, 100, 100);
		
		add(pass);
		pass.setBounds(20, 120, 100, 30);
		add(pass1);
		pass1.setBounds(100, 120, 130, 30);
		
		JLabel myPass = new JLabel("<html>PassCode is <div style=\"color:green \"> RETROTECH@ciu&OGHOGHOnapoleon</div></html>");
		add(myPass);
		myPass.setBounds(20, 160, 250, 35);
		
		
		add(enter);
		enter.setBounds(70, 200, 150, 30);
		enter.setFont(new Font("",Font.BOLD,20));
		
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro", "root", "");
					Statement stm = conn.createStatement();
					String sql = "Select * from admin where passcode='"+pass1.getText()+"'";
					
					String myUser = pass1.getText();
					
					if(myUser.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Please enter Pass-Code");
					}
					else {
						ResultSet myResult = stm.executeQuery(sql);
						if(myResult.next()) {
							JOptionPane.showMessageDialog(null, "ACCESS GRANTED SUCCESSFULLY");
							new DataHouse();
							dispose();
						}
						else {
							JOptionPane.showMessageDialog(null, "ACCESS DENIED");
						}
					}
					
					
					
				}
			
				catch(Exception b) {
					System.out.println(b);
				}
				
				
			}
		});
		
	}
	
	

}
