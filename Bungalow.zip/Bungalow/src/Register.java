import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Register extends JFrame implements ActionListener{
	JLabel labelName = new JLabel("First Name:");
	JLabel labelSurname = new JLabel("Surname:");
	JLabel labelUser = new JLabel("Username:");
	JLabel labelPassword = new JLabel("Password:");
	JLabel labelConfirmPassword = new JLabel("Confirm Password:");
	JLabel labelAddress = new JLabel("Address:");
	JLabel labelPhone = new JLabel("Phone Number:");
	JLabel labelEmail = new JLabel("Email:");
	JLabel labelGender= new JLabel("Gender:");
	JLabel already = new JLabel("Already a member ?   please ");

	JTextField fieldName = new JTextField(40);
	JTextField fieldSurname = new JTextField(40);
	JTextField fieldUser = new JTextField(30);
	JTextField fieldPassword = new JTextField(40);
	JTextField fieldConfirmPassword = new JTextField(40);
	JTextField fieldAddress = new JTextField(50);
	JTextField fieldPhone = new JTextField(20);
	JTextField fieldEmail = new JTextField(40);
	JCheckBox male = new JCheckBox("Male", false);
	JCheckBox female = new JCheckBox("Female", false);
	ButtonGroup Gender = new ButtonGroup();
	private String gender;
	
	JButton register = new JButton("Register");
	JButton login = new JButton("Login");


	public static void main (String [] args) {
		Register RegisterRegister = new Register();
	}


	Register(){
		setLayout(null);
		setResizable(false);
		setMinimumSize(new Dimension(700,500));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Retechpro Registration Page");
		setLocationRelativeTo(null);
		setVisible(true);



		add(labelName);
		add(labelSurname);
		add(labelUser);
		add(labelPassword);
		add(labelConfirmPassword);
		add(labelAddress);
		add(labelPhone);
		add(labelEmail);
		add(labelGender);

		add(fieldName);
		add(fieldSurname);
		add(fieldUser);
		add(fieldPassword);
		add(fieldConfirmPassword);
		add(fieldAddress);
		add(fieldPhone);
		add(fieldEmail);
		add(already);
		add(register);
		add(login);

		add(male);
		add(female);
		Gender.add(male);
		Gender.add(female);

		labelName.setBounds(10, 10, 100, 30);
		labelSurname.setBounds(10, 50, 100, 30);
		labelUser.setBounds(10, 90, 100, 30);
		labelPassword.setBounds(10, 130, 100, 30);
		labelConfirmPassword.setBounds(10, 170, 150, 30);
		labelAddress.setBounds(10, 210, 100, 30);
		labelPhone.setBounds(10, 250, 100, 30);
		labelEmail.setBounds(10, 290, 100, 30);
		labelGender.setBounds(10, 330, 100, 30);

		fieldName.setBounds(100, 10, 200, 30);
		fieldSurname.setBounds(100, 50, 200, 30);
		fieldUser.setBounds(100, 90, 200, 30);
		fieldPassword.setBounds(100, 130, 200, 30);
		fieldConfirmPassword.setBounds(150, 170, 200, 30);
		fieldAddress.setBounds(100, 210, 200, 30);
		fieldPhone.setBounds(100, 250, 200, 30);
		fieldEmail.setBounds(100, 290, 200, 30);
		male.setBounds(100, 330, 80, 30);
		female.setBounds(190, 330, 100, 30);

		register.setBounds(290,340,200,40);
		register.setFont(new Font("",Font.BOLD,30));
		already.setBounds(10,420,200,30);
		login.setBounds(180,420,90,30);
		
		
		/*male.addItemListener(new ItemListener() {    
            public void itemStateChanged(ItemEvent e) {                 
             gender="male";   
            }    
         });    
		
		female.addItemListener(new ItemListener() {    
            public void itemStateChanged(ItemEvent e) {                 
             gender="female";   
            }    
         });   */
		
		male.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender="male";

			}
		});
		
		female.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gender="female";

			}
		});



		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login();
				dispose();

			}
		});

		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {




				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retechpro", "root", "");
					PreparedStatement std = conn.prepareStatement("insert into customers(firstName,surname,username,password,confirmPassword,address,phoneNumber,email,gender) values(?,?,?,?,?,?,?,?,?)");
					std.setString(1, fieldName.getText());
					std.setString(2, fieldSurname.getText());
					std.setString(3, fieldUser.getText());
					std.setString(4, fieldPassword.getText());
					std.setString(5, fieldConfirmPassword.getText());
					std.setString(6, fieldAddress.getText());
					std.setString(7, fieldPhone.getText());
					std.setString(8, fieldEmail.getText());
					std.setString(9, gender);
					


					String Name = fieldName.getText();
					String surname = fieldSurname.getText();
					String username = fieldUser.getText();
					String password = fieldPassword.getText();
					String confirmPassword = fieldConfirmPassword.getText();
					String address = fieldAddress.getText();
					String phone = fieldPhone.getText();
					String email = fieldEmail.getText();
					String sex = gender;
					//	String genderMale = male.getText();
					//	String genderFemale = female.getText();

					//String genderMale1 = male.is;
					//String genderFemale1 = female.isSelected();

					if(Name.isEmpty()) {
						JOptionPane.showMessageDialog(null, "First Name Required");
					}
					else {
						if(surname.isEmpty()) {
							JOptionPane.showMessageDialog(null, "Surname Required");
						}
						else {
							if(username.isEmpty()) {
								JOptionPane.showMessageDialog(null, "username Required");
							}
							else {
								if(address.isEmpty()) {
									JOptionPane.showMessageDialog(null, "Address Required");
								}
								else {
									if(phone.isEmpty()) {
										JOptionPane.showMessageDialog(null, "Phone Number Required");
									}
									else {
										if(email.isEmpty()) {
											JOptionPane.showMessageDialog(null, "Email Required");
										}
										else {
											if(!(confirmPassword.equals(password))) {
												JOptionPane.showMessageDialog(null, "Password mis-match");
											}
											else {
												//if((gender.isEmpty() || gender.isEmpty()) || (gender.isEmpty() && gender.isEmpty())) {
												//if(sex.isEmpty()) {
												if(gender.isEmpty()) {
												JOptionPane.showMessageDialog(null, "Gender required");
													
												}
												else {
													
													int x = std.executeUpdate();
													if(x>0) {
														JOptionPane.showMessageDialog(null, "Registration Successful");
														new Home();
														dispose();
													}
													else {
														JOptionPane.showMessageDialog(null, "Registration FAILED");
													}
													
												}

											}
										}
									}
								}
							}
						}
					}







				}
				catch(Exception ea) {
					System.out.println(ea);
				}


			}
		});


	}




	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}




}

